import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms'; // Add this import statement

import { AppComponent } from './app.component';
import { KafkaComponent } from './kafka/kafka.component';

@NgModule({
  declarations: [AppComponent, KafkaComponent],
  imports: [BrowserModule, HttpClientModule, FormsModule], // Add FormsModule to the imports array
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
