import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

interface Topic {
  name: string;
  partitions: Partition[];
}

interface Partition {
  partition: number;
  offset: number;
  consumers: string[];
}

@Component({
  selector: 'app-kafka',
  templateUrl: './kafka.component.html',
  styleUrls: ['./kafka.component.css'],
})
export class KafkaComponent implements OnInit {
  topics: Topic[] = [];
  selectedTopic: Topic | null = null;
  message: string = '';
  responseMessage: string = '';
  newTopicName: string = '';

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.loadTopicDetails();
  }

  loadTopicDetails() {
    this.http.get<any>('http://localhost:3000/topics').subscribe((response) => {
      this.topics = response.topics;
    });
  }

  selectTopic(topic: Topic) {
    this.selectedTopic = topic;
    console.log(this.selectedTopic);
  }

  sendMessage() {
    if (!this.selectedTopic) {
      return;
    }

    const topicName = this.selectedTopic;
    const payload = { message: this.message };

    this.http
      .post<any>(`http://localhost:3000/topics/${topicName}/send`, payload)
      .subscribe((response) => {
        console.log('Message sent successfully:', response);
        this.responseMessage = response.message;
        // Reset message input
        this.message = '';
      });
  }

  createTopic() {
    if (!this.newTopicName) {
      return;
    }

    const payload = { topicName: this.newTopicName };

    this.http
      .post<any>('http://localhost:3000/topic', payload)
      .subscribe((response) => {
        console.log('Topic created successfully:', response);
        // Refresh topic list
        this.loadTopicDetails();
        // Clear new topic name input
        this.newTopicName = '';
      });
  }
}
