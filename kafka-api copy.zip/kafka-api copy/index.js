process.env["DEBUG"] = "kafka-node:*";
const express = require("express");
const bodyParser = require("body-parser");
const kafka = require("kafka-node");
const cors = require("cors");

const app = express();
const port = 3000;
const kafkaHost = "localhost:9092";

// Create Kafka client and admin client
const client = new kafka.KafkaClient({ kafkaHost });
const producer = new kafka.Producer(client);
const admin = new kafka.Admin(client);

// Body parser middleware
app.use(bodyParser.json());
app.use(cors());

// Get topic names
app.get("/topics", (req, res) => {
  client.loadMetadataForTopics([], (error, result) => {
    if (error) {
      console.error(`Error retrieving topic names: ${error}`);
      return res
        .status(500)
        .json({ error: "An error occurred while retrieving topic names." });
    }

    const topics = Object.keys(result[1].metadata);
    res.json({ topics });
  });
});

app.post("/topic", (req, res) => {
  const { topicName } = req.body;
  const topics = [
    {
      topic: topicName,
      partitions: 3, // Specify the number of partitions for the topic
      replicationFactor: 1, // Specify the replication factor for the topic
    },
  ];

  admin.createTopics(topics, (error, result) => {
    if (error) {
      console.error(`Error creating topic: ${error}`);
      return res
        .status(500)
        .json({ error: "An error occurred while creating the topic." });
    }
    res.json({ message: `Topic "${topicName}" created successfully.` });
  });
});

// Send message to a topic
app.post("/topics/:topicName/send", (req, res) => {
  const { topicName } = req.params;
  const { message } = req.body;

  console.log(`Received message ${message}`);

  const payloads = [{ topic: topicName, messages: message }];

  producer.send(payloads, (error, data) => {
    if (error) {
      console.error(`Error sending message to topic: ${error}`);
      return res
        .status(500)
        .json({ error: "An error occurred while sending the message." });
    }
    res.json({ message: "Message sent successfully to " + topicName, data });
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

// Handle server shutdown
process.on("SIGINT", () => {
  console.log("Shutting down the server...");

  // Close the Kafka producer before exiting
  producer.close(() => {
    console.log("Kafka producer closed.");
    process.exit();
  });
});
